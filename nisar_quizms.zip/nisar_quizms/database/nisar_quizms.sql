-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2023 at 06:56 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nisar_quizms`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_status` int(100) NOT NULL COMMENT 'active=1 inactive=0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `category_status`) VALUES
(1, 'Madical', 1),
(6, 'Current afairs', 1),
(7, 'Lawyer', 1),
(8, 'Software  Eng', 1),
(14, 'Politics', 1),
(22, 'Elictrical Eng', 0),
(23, 'Biology', 0),
(24, 'computer', 0),
(25, 'Sociology', 0),
(26, 'physics1', 0),
(27, 'urdo', 0),
(28, 'Pak Study', 0);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `question_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `option1` varchar(100) NOT NULL,
  `option2` varchar(100) NOT NULL,
  `option3` varchar(100) NOT NULL,
  `option4` varchar(100) NOT NULL,
  `correct_option` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` date DEFAULT NULL,
  `category_id` varchar(100) NOT NULL,
  `question_status` varchar(100) NOT NULL COMMENT 'active=1 , inactive=0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`question_id`, `title`, `description`, `option1`, `option2`, `option3`, `option4`, `correct_option`, `status`, `updated_by`, `created_by`, `created_at`, `updated_at`, `category_id`, `question_status`) VALUES
(11, 'SQl Stands For what?', '', 'Structure question law', 'structure query language', 'Structure question library', 'Structure question leave', 'Option No 2', '', '', '', '2023-01-04 14:53:55', NULL, '8', ''),
(12, 'Botony Is inn which Field?', '', 'Madical', 'Engineering', 'Politics', 'Other', 'Option No 1', '', '', '', '2023-01-04 15:02:30', NULL, '1', ''),
(13, 'Sociology is in which field?', '', 'Engineering', 'Madical', 'Politics', 'other', 'Option No 2', '', '', '', '2023-01-04 15:04:00', NULL, '1', ''),
(14, 'Peshawar is in which  province in pakistan?', '', 'Punjab', 'KPK', 'Sindh', 'Balochistan', 'Option No 2', '', '', '', '2023-01-04 15:05:35', NULL, '6', ''),
(15, 'Imran khan is in which party chairman?', '', 'PMLN', 'MQM', 'PTI', 'PPP', 'Option No 3', '', '', '', '2023-01-04 15:06:49', NULL, '14', ''),
(16, 'Amphere is the unit of?', '', 'Current', 'electron', 'neutro', 'proton', 'Option No 1', '', '', '', '2023-01-04 15:14:29', NULL, '22', ''),
(17, ' How many bones make up an adult skeleton?', '', '202', '207', '206', '210', 'Option No 3', '', '', '', '2023-01-05 12:02:46', NULL, '1', ''),
(18, ' What is the name of the country that has stated that they will open their air space to all airline ', '', 'Pakistan', 'India', 'Iran', 'Saudi Arabia.', 'Option No 4', '', '', '', '2023-01-05 12:04:30', NULL, '6', ''),
(19, 'In.which year is India expected to become the most populated country in the world?', '', '2000', '2023', '2006', '2008', 'Option No 2', '', '', '', '2023-01-05 12:05:11', NULL, '6', ''),
(20, ' Which nation will sign a safety agreement with the Taliban?', '', 'qatar', 'pakistan', 'iran', 'india', 'Option No 1', '', '', '', '2023-01-05 12:09:30', NULL, '6', ''),
(21, ' Which country was the host of the Winter Olympics in 2022?', '', 'iran', 'India', 'Sindh', 'china', 'Option No 4', '', '', '', '2023-01-05 12:15:58', NULL, '6', ''),
(22, ' What was the first country to give a DNA vaccine against COVID?', '', 'iran', 'pakistan', 'india', 'china', 'Option No 3', '', '', '', '2023-01-05 12:16:54', NULL, '6', ''),
(23, 'In which year was the Right to Education Act enacted?', '', '2002', '2009', '2013', '2017', 'Option No 2', '', '', '', '2023-01-05 12:19:51', NULL, '7', ''),
(24, 'What is a ‘Zero FIR’?', '', 'An FIR which can be filed at any police station .', ' An FIR which is closed due to lack of evidence.', 'An FIR which is filed by another party on behalf of the victim.', 'None of the above', 'Option No 1', '', '', '', '2023-01-05 12:21:35', NULL, '7', ''),
(25, 'What is the Voir-Dire Test?', '', 'It is used to determine whether the facts.', 'It is used to determine whether a child .', ' It is used to determine whether victims of sexual assaul. give a statement.', 'None of the above', 'Option No 2', '', '', '', '2023-01-05 12:23:49', NULL, '7', ''),
(26, 'The provision of ‘caveat’ in CPC corresponds to which criminal procedure?', '', ' Attachment and Seizure', 'Summary Trial', ' Anticipatory Bail', 'n', 'Option No 3', '', '', '', '2023-01-05 12:25:51', NULL, '7', ''),
(27, 'The concept of ‘fundamental duties’ in the Indian Constitution was borrowed from?', '', 'iran', 'Japan', 'France', 'Russia', 'Option No 4', '', '', '', '2023-01-05 12:28:33', NULL, '7', ''),
(28, 'CPU Stand for?', '', 'Central Project Uper', 'Central processing unit', 'Central Project Umar', 'Central Project uder', 'Option No 2', '', '', '', '2023-01-05 12:34:08', NULL, '8', ''),
(29, ' Who is the Father of the Computer?', '', 'Charles Babbage', 'Thomas Edison', 'Albert Einstein', 'Isaac Newton', 'Option No 1', '', '', '', '2023-01-05 12:54:21', NULL, '8', ''),
(30, ' What is the full form of E-Mail?', '', 'Electric Mail ', 'Exchange Mail', ' Electronic Mail', ' Engagement Mail', 'Option No 3', '', '', '', '2023-01-05 12:55:19', NULL, '8', ''),
(31, ' Who invented Compact Disc?', '', 'James T. Russell    ', 'Fujio Masuoka', 'Thomas Edison', 'Martin Cooper', 'Option No 1', '', '', '', '2023-01-05 12:58:27', NULL, '8', ''),
(32, ' Which one of the following is not an Operating System (OS)?', '', 'Windows 10 ', 'DOS', 'Routers', ' MS Excel', 'Option No 3', '', '', '', '2023-01-05 12:59:48', NULL, '8', ''),
(33, ' What do you need to use to connect to the internet?', '', 'Mouse', 'Keyboard', 'CPU ', ' Modem ', 'Option No 4', '', '', '', '2023-01-05 13:01:48', NULL, '8', ''),
(34, '18th amendment stripped powers of _____?', '', 'PM   ', 'President ', '  Chief Executive  ', 'Chairman NAB', 'Option No 2', '', '', '', '2023-01-05 13:04:52', NULL, '14', ''),
(35, 'The amendment after which Pakistan turned to be pure Parliamentary government ?', '', ' 19th ', ' 22nd ', ' 21st  ', '18th ', 'Option No 4', '', '', '', '2023-01-05 13:06:09', NULL, '14', ''),
(36, 'The government in Pakistan consists of __ branches ?', '', 'Two ', ' Four  ', 'Five  ', ' Three ', 'Option No 4', '', '', '', '2023-01-05 13:07:03', NULL, '14', ''),
(37, 'The Branch in the government whose cabinet is led by Prime Minister of Pakistan is?', '', ' Executive  ', 'Judicial', 'Legislative  ', '  None  ', 'Option No 1', '', '', '', '2023-01-05 13:08:00', NULL, '14', ''),
(38, 'The Branch in the government whose cabinet is led by Prime Minister of Pakistan is?', '', ' Executive  ', 'Judicial', 'Legislative  ', '  None  ', 'Option No 1', '', '', '', '2023-01-05 13:08:01', NULL, '14', ''),
(39, 'In Pakistan, President can hold office for until __ consecutive periods ?', '', ' Three ', 'Two ', ' Four ', ' None  ', 'Option No 2', '', '', '', '2023-01-05 13:09:20', NULL, '14', ''),
(40, 'Power of presidency to dissolve National assembly and dismiss PM, was stripped by ____ amendment?', '', ' 8th ', '18th  ', '  13th  ', ' 9th', 'Option No 3', '', '', '', '2023-01-05 13:10:56', NULL, '14', ''),
(41, 'What are the practical applications of variable resistance?', '', 'Volume control ', 'Light dimmer', 'Fan speed control ', 'None of the above', 'Option No 1', '', '', '', '2023-01-05 13:13:07', NULL, '22', ''),
(42, ' Which of the following elements of electrical engineering cannot be analyzed using Ohm’s law?', '', 'a)Capacitors ', 'b) Inductors', ' c) Transistors ', 'd) Resistance', 'Option No 3', '', '', '', '2023-01-05 13:18:27', NULL, '22', ''),
(43, 'If 1 A current flows in a circuit, the number of electrons flowing through this circuit is?', '', ' 0.625 × 1019 ', '0.625 × 10 - 19', ' 1.6 × 10 - 19  ', ' 1.6 × 1019 ', 'Option No 1', '', '', '', '2023-01-05 13:22:29', NULL, '22', ''),
(44, 'How many coulombs of charge flow through a circuit carrying a current of 10 A in 1 minute?', '', ' 10 ', ' 600 ', ' 1200', ' 60 ', 'Option No 2', '', '', '', '2023-01-05 13:24:08', NULL, '22', ''),
(45, ' A capacitor carries a charge of 0.1 C at 5 V. Its capacitance is', '', ' 0.5 F  ', ' 0.2 F', '0.05 F ', ' 0.02 F ', 'Option No 4', '', '', '', '2023-01-05 13:25:15', NULL, '22', ''),
(46, 'To obtain a high value of capacitance, the permittivity of dielectric medium should be?', '', ' low ', ' high ', ' unity', ' zero ', 'Option No 2', '', '', '', '2023-01-05 13:26:43', NULL, '22', ''),
(47, 'is the partial or complete wasting away of a part of a body.', '', ' Atrophy ', ' Noma', ' Tetanus ', 'Leprosy ', 'Option No 1', '', '', '', '2023-01-05 13:30:53', NULL, '1', ''),
(48, ' Which of the following statements is true about drug Imodium?', '', ' Slows the rate at which the stomach and oesophagus move', 'None of these', 'Decrease density of stools ', ' Encourages water and electrolytes reabsorption ', 'Option No 4', '', '', '', '2023-01-05 13:33:27', NULL, '1', ''),
(49, ' Hypovolaemia can be treated by:?', '', 'Oral replacement solution', '5% dextrose', ' Colloid Solution', ' 0.6% Saline', 'Option No 3', '', '', '', '2023-01-05 13:34:26', NULL, '1', ''),
(50, 'Effects of having Thiamine deficiency are:?', '', 'Muscle weakness', ' Central nervous system and Cardiovascular problems', ' Heart disease and Beri beri disease', 'All of these', 'Option No 4', '', '', '', '2023-01-05 13:35:39', NULL, '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `subject_status` int(11) NOT NULL COMMENT 'active=1, inactive=0',
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `subject_status`, `category_id`) VALUES
(1, 'Biology ', 1, 1),
(2, 'Maths', 0, 1),
(3, 'test', 0, 22),
(5, 'Physics 2', 0, 1),
(6, 'Botony', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_code` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_code`, `fullname`, `username`, `password`, `level`) VALUES
(1, 'Administrator', 'admin', '8d804a5c53b69a7342c5c3c7ddc5364d', 'admin'),
(2, 'Samantha Lou', 'sam', '56fafa8964024efa410773781a5f9e93', 'cashier'),
(3, 'Adnan Saib', 'adnan', '044f414bd17887bf6e3f45a414d71002', 'admin'),
(5, 'admin', 'admin', 'admin', 'admin'),
(6, 'Nisar Ahmad', 'nisar', 'dafe51d37cec7495f78992b8ae82f5e0', 'admin'),
(7, 'admin', 'admin', 'e00cf25ad42683b3df678c61f42c6bda', 'admin'),
(8, 'Admin Saab', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(9, 'Hasnain Saib', 'Hasnain', 'f926d1ee342bbe4963c635e80c3b0ba7', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
