<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_subject extends CI_Model {

	public function get_subject()
	{
		$tm_subject= $this->db->join('category','category.category_id=subject.category_id')
		             ->get('subject')->result();

		  return $tm_subject;
	}
	public function amount_data(){
		return $this->db->get('subject')->num_rows();
	}
	public function data_category()
	{
		return $this->db->get('category')->result();
	}
	public function save_subject($nama_file)
	{
		if ($nama_file=="") {
				$object=array(
						'subject_name'=>$this->input->post('subject_name'),
						'category_id'=>$this->input->post('category')
						);

			}	else {
				$object=array(
						'subject_name'=>$this->input->post('subject_name'),
					
						'category_id'=>$this->input->post('category'),
						

					);
			}
			return $this->db->insert('subject', $object);
		}

		public function detail($a)
		{
			$tm_subject=$this->db->join('category', 'category.category_id=subject.category_id')
			->where('subject_id',$a)
			->get('subject')
			->row();
			return $tm_subject;
		}

		public function subject_update_no_foto()
		{
			$object=array(
					    'subject_name'=>$this->input->post('subject_name'),
					
						'category_id'=>$this->input->post('category')
						
				);
				return $this->db->where('subject_id', $this->input->post('subject_id_lama'))->update('subject',$object);

		}
		public function subject_update_dengan_foto($nama_foto='')
		{
			$object=array(
						'subject_name'=>$this->input->post('subject_name'),
					
						'category_id'=>$this->input->post('category'),

					);
					return $this->db->where('subject_id', $this->input->post('subject_id_lama'))->update('subject',$object);


		}
		public function hapus_subject($subject_id='')
		{
			return $this->db->where('subject_id', $subject_id)->delete('subject');
		}

		
		function subject_update($array, $subject_id)
		{ 
		 return $this->db->where('subject_id',$subject_id)->update('subject',$array);
		}

}

/* End of file M_book.php */
/* Location: ./application/models/M_book.php */