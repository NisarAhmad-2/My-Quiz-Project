<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_category extends CI_Model {

	public function get_category()
	{
		$tm_category=$this->db->get('category')->result();
		return $tm_category;
	}

	public function save_kat()
	{
		$object=array(
				'category_id'=>$this->input->post('category_id'),
				'category_name'=>$this->input->post('category_name')
			);
		return $this->db->insert('category', $object);;
	}
	public function detail($a)
	{
		return $this->db->where('category_id', $a)
						->get('category')
						->row();
	}
	public function edit_kat()
	{
		$object=array(
				'category_id'=>$this->input->post('category_id'),
				'category_name'=>$this->input->post('category_name')
			);
		return $this->db->where('category_id', $this->input->post('category_id_lama'))->update('category',$object);
	}

	public function hapus_kat($id='')
	{
		return $this->db->where('category_id', $id)->delete('category');
	}

	
}

/* End of file M_category.php */
/* Location: ./application/models/M_category.php */