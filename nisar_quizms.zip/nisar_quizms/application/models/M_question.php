<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_question extends CI_Model {

	public function get_question()
	{
		$tm_question=  $this->db->join('category','category.category_id=question.category_id')
		              ->get('question')->result();
		return $tm_question;
	}
	public function amount_data(){
		return $this->db->get('question')->num_rows();
	}
	public function data_category()
	{
		return $this->db->get('category')->result();
	}
	public function save_question($nama_file)
	{
		if ($nama_file=="") {
				$object=array(
							'title'=>$this->input->post('title'),
							'option1'=>$this->input->post('option1'),
							'option2'=>$this->input->post('option2'),
							'option3'=>$this->input->post('option3'),
							'option4'=>$this->input->post('option4'),
							'correct_option'=>$this->input->post('correct_option'),
							'category_id'=>$this->input->post('category')

					);
			}	else {
				$object=array(
							'title'=>$this->input->post('title'),
							'option1'=>$this->input->post('option1'),
							'option2'=>$this->input->post('option2'),
							'option3'=>$this->input->post('option3'),
							'option4'=>$this->input->post('option4'),
							'correct_option'=>$this->input->post('correct_option'),
							'category_id'=>$this->input->post('category'),

					);
			}
			return $this->db->insert('question', $object);
		}

		public function detail($a)
		{
			$tm_question=$this->db->join('category', 'category.category_id=question.category_id')
			->where('question_id',$a)
			->get('question')
			->row();
			return $tm_question;
		}

		public function question_update_no_foto()
		{
			$object=array(
						'title'=>$this->input->post('title'),
						'option1'=>$this->input->post('option1'),
						'option2'=>$this->input->post('option2'),
						'option3'=>$this->input->post('option3'),
						'option4'=>$this->input->post('option4'),
						'correct_option'=>$this->input->post('correct_option'),
						'category_id'=>$this->input->post('category')
				);
			return $this->db->where('question_id', $this->input->post('question_id'))
							->update('question',$object);

		}
		public function question_update_dengan_foto($nama_foto='')
		{
			$object=array(
						'title'=>$this->input->post('title'),
						'option1'=>$this->input->post('option1'),
						'option2'=>$this->input->post('option2'),
						'option3'=>$this->input->post('option3'),
						'option4'=>$this->input->post('option4'),
						'correct_option'=>$this->input->post('correct_option'),
						'category_id'=>$this->input->post('category'),

					);
			return $this->db->where('question_id', $this->input->post('question_id'))
							->update('question',$object);

		}

		    //  process of delete //
		public function hapus_question($question_id='')
		{
			return $this->db->where('question_id', $question_id)->delete('question');
		}
		
        //    process of update//

		function question_update($array, $question_id)
		{ 
		 return $this->db->where('question_id',$question_id)->update('question',$array);
		}

}

/* End of file M_question.php */
/* Location: ./application/models/M_question.php */