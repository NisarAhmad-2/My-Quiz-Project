<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class question extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_question','question');
	}
	public function index()
	{
		$this->load->library('pagination');
		$amount_data = $this->question->amount_data();
		$data['get_question']=$this->question->get_question();
		$data['category']=$this->question->data_category();
		$data['content']="v_question";

		$data['total_rows'] = $amount_data;
		$data['per_page'] = 1;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($data);		
		$data['user'] = $this->question->get_question($data['per_page'],$from);

		$this->load->view('template', $data, FALSE);
	} 
	    //  process of Add //
	public function add()
	{
		$this->form_validation->set_rules('title', 'title', 'trim|required');
		$this->form_validation->set_rules('option1', 'option1', 'trim|required');
		$this->form_validation->set_rules('option2', 'option2', 'trim|required');
		$this->form_validation->set_rules('option3', 'option3', 'trim|required');
		$this->form_validation->set_rules('option4', 'option4', 'trim|required');
		$this->form_validation->set_rules('correct_option', 'correct_option', 'trim|required');
		$this->form_validation->set_rules('category', 'category', 'trim|required');

			if ($this->question->save_question('')) {
				$this->session->set_flashdata('message', 'question has been added successfully');
			} else {
				$this->session->set_flashdata('message', 'question has failed to Add');
			}
			redirect('question','refresh');
		}
	
	public function edit_question($question_id)
	{
		$data=$this->question->detail($question_id);
		echo json_encode($data);
	}

	// public function question_update()
	// {
	// 	if ($this->input->post('save')) {
			
	// 				$this->session->set_flashdata('message', 'question Details has been updated successfully.');
	// 				redirect('question');
	// 			} else {
	// 				$this->session->set_flashdata('message', 'Failed to update');
	// 				redirect('question');
	// 			}
	// } 
		    //  Process of question //
	public function question_update()
	{
		if ($this->input->post('save')) 
		  {
				  $array = array
				  (
					'title'   =>$this->input->post('title'),
					'option1' =>$this->input->post('option1'),
					'option2' =>$this->input->post('option2'),
					'option3' =>$this->input->post('option3'),
					'option4' =>$this->input->post('option4'),
					'correct_option' =>$this->input->post('correct_option'),
					'category_id' =>$this->input->post('category'),
				  ); 
				 $response = $this->question->question_update($array,$this->input->post('question_id'));
				 if($response == true)
				 {
					$this->session->set_flashdata('message', 'question Details has been updated successfully.');
					redirect('question');
				 }
				 else
				 {
					$this->session->set_flashdata('message', 'Something went wrong please try again');
					redirect('question');
				 }
	     }
	} 
	
            //  Delete process//
	public function hapus($question_id='')
	{
		if ($this->question->hapus_question($question_id)) {
			$this->session->set_flashdata('message', 'question has been deleted successfully.');
			redirect('question','refresh');
		} else {
			$this->session->set_flashdata('message', 'Delete Failed');
			redirect('question','refresh');
		}
	}

}

/* End of file book.php */
/* Location: ./application/controllers/book.php */