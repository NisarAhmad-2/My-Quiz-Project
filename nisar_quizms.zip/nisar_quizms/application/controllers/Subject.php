<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subject extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_subject','subject');
	}
	public function index()
	{
		$this->load->library('pagination');
		$amount_data = $this->subject->amount_data();
		$data['get_subject']=$this->subject->get_subject();
		$data['category']=$this->subject->data_category();
		$data['content']="v_subject";

		$data['total_rows'] = $amount_data;
		$data['per_page'] = 1;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($data);		
		$data['user'] = $this->subject->get_subject($data['per_page'],$from);

		$this->load->view('template', $data, FALSE);
	}
	public function add()
	{
		$this->form_validation->set_rules('subject_name', 'subject_name', 'trim|required');
		$this->form_validation->set_rules('category', 'category', 'trim|required');

			if ($this->subject->save_subject('')) {
				$this->session->set_flashdata('message', 'Subject has been added successfully');
			} else {
				$this->session->set_flashdata('message', 'Subject has failed to Add');
			}
			redirect('subject','refresh');
		}
	
	public function edit_subject($id)
	{
		$data=$this->subject->detail($id);
		echo json_encode($data);
	}

	public function subject_update()
	{
		if ($this->input->post('save')) 
		{
				  $array = array
				  (
					  'subject_name'=>$this->input->post('subject_name'),
					  'category_id' =>$this->input->post('category'),
				  ); 
				 $response = $this->subject->subject_update($array,$this->input->post('subject_id'));
				 if($response == true)
				 {
					$this->session->set_flashdata('message', 'subject Details has been updated successfully.');
					redirect('subject');
				 }
				 else
				 {
					$this->session->set_flashdata('message', 'Something went wrong please try again');
					redirect('subject');
				 }
					
					// } else {
					// 	$this->session->set_flashdata('message', 'Failed to update');
					// 	redirect('subject');
					// 
	  }
	} 
		
	

	public function hapus($subject_id='')
	{
		if ($this->subject->hapus_subject($subject_id)) {
			$this->session->set_flashdata('message', 'Subject has been deleted successfully.');
			redirect('subject','refresh');
		} else {
			$this->session->set_flashdata('message', 'Delete Failed');
			redirect('subject','refresh');
		}
	}

}

/* End of file book.php */
/* Location: ./application/controllers/book.php */