<header class="page-header">
  <div class="container-fluid">
       <h4 class="no-margin-bottom mb-5 text-center" style="color:blue;"> <strong> Subjects Detail </strong> </h4> 
  </div>
</header>
 <div class="container-fluid mb-5">
  <div class="table-agile-info">
	
		<?php if ($this->session->flashdata('message')!=null) 
		
		{
		  echo "<br><div class='alert alert-success alert-dismissible fade show' role='alert'>"
			.$this->session->flashdata('message')."<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			<span aria-hidden='true'>&times;</span>
			</button> </div>";
		} ?>

		<br>
		<div class="card rounded-0 shadow mb-5 mx-5">
			<div class="card-header">
				<a href="#add" data-toggle="modal" class="btn btn-primary btn-sm rounded-0 pull-right"><i class="fa fa-plus"></i> <strong> Add New Subject </strong></a>
			</div>
			<div class="card-body mb-5 ">
				<table class="table table-hover table-bordered" id="example" ui-options=ui-options="{
					&quot;paging&quot;: {
					&quot;enabled&quot;: true
					},
					&quot;filtering&quot;: {
					&quot;enabled&quot;: true
					},
					&quot;sorting&quot;: {
					&quot;enabled&quot;: true
					}}">
					<thead style="background-color: #464b58; color:white;">
						<tr>
							<td>#</td>
							<td>Subject Name</td>
							<td>Category Name</td>
							<td class="text-center">Action</td>
						</tr></thead>
						<tbody style="background-color: white; mt-5">
						<?php $no=0; foreach ($get_subject as $subject) : $no++;?>

						<tr>
							<td><?=$no?></td>
							<td><?=$subject->subject_name?></td>
							
							<td><?=$subject->category_name?></td>
							<td class="text-center">
								<a href="#edit" onclick="edit('<?=$subject->subject_id?>')" class="btn btn-primary btn-sm rounded-0" data-toggle="modal"><i class="fa fa-pencil"></i>Edit</a>
								<a href="<?=base_url('index.php/subject/hapus/'.$subject->subject_id)?>" onclick="return confirm('Are you sure to delete this book?')" class="btn btn-danger btn-sm rounded-0"><i class="fa fa-trash"></i>Delete</a>
							</td>
						</tr>
					<?php endforeach ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="modal" id="add">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					Add New Subject
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
					</button>
				</div>
				<form action="<?=base_url('index.php/subject/add')?>" method="post" enctype="multipart/form-data">
					<div class="modal-body">
						<div class="form-group row">
							<div class="col-sm-3 offset-1"><label>Subject Name</label></div>
							<div class="col-sm-7">
								<input type="text" name="subject_name" required="form-control" class="form-control">
							</div>
						</div>
						
						<div class="form-group row">
							<div class="col-sm-3 offset-1"><label>Category</label></div>
							<div class="col-sm-7">
								<select name="category" required="form-control" class="form-control">
									<?php foreach ($category as $kat): ?>
										<option value="<?=$kat->category_id?>">
											<?=$kat->category_name ?>
										</option> 
									<?php endforeach ?>
								</select>
							</div>
						</div>
						
						
						
					</div>
					<div class="modal-footer justify-content-end">
						<input type="submit" name="save" value="Save" class="btn btn-primary btn-sm rounded-0">
						<button type="button" class="btn btn-default btn-sm border rounded-0" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="modal fade" id="edit">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					Update Subject
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
					</button>
				</div>
				<form action="<?=base_url('index.php/subject/subject_update')?>" method="post" enctype="multipart/form-data">
					<input type="hidden" name="subject_id" id="subject_id">
					<div class="modal-body">
						<div class="form-group row">
							<div class="col-sm-3 offset-1"><label>Subject Name</label></div>
							<div class="col-sm-7">
								<input type="text" name="subject_name" id="subject_name" class="form-control">
							</div>
						</div>
						
						
						<div class="form-group row">
							<div class="col-sm-3 offset-1"><label>Category</label></div>
							<div class="col-sm-7">
								<select name="category" id="category" class="form-control">
									<?php foreach ($category as $kat): ?>
										<option value="<?=$kat->category_id?>">
											<?=$kat->category_name ?>
										</option> <?php endforeach ?>
								</select>
							</div>
						</div>
						
					</div>
					<div class="modal-footer justify-content-end">
						<input type="submit" name="save" value="Save" class="btn btn-primary btn-sm rounded-0">
						<button type="button" class="btn btn-default btn-sm border rounded-0" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div>
			
		</div>
	</div>
 </div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
			$('#example').DataTable();
		}
	);
	function edit(a) {
		$.ajax({
			type:"post",
			url:"<?=base_url()?>index.php/subject/edit_subject/"+a,
			dataType:"json",
			success:function(data){
				$("#subject_id").val(data.subject_id);
				$("#subject_name").val(data.subject_name);
				$("#category").val(data.category_id);
				//  $("#subject_id_lama").val(data.subject_id);

			}
		});
	}
</script>
