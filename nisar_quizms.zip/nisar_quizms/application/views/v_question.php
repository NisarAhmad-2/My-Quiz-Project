<header class="page-header">
  <div class="container-fluid">
  <h4 class="no-margin-bottom text-center" style="color:blue;"> <strong> All Questions </strong>
  </div>
</header>

<div class="container-fluid mb-5">
 <div class="table-agile-info">
		<?php if ($this->session->flashdata('message')!=null) {
		echo "<br><div class='alert alert-success alert-dismissible fade show' role='alert'>"
			.$this->session->flashdata('message')."<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			<span aria-hidden='true'>&times;</span>
			</button> </div>";
		} ?>
		<br>
		<div class="card rounded-0 shadow">
			<div class="card-header">
				<a href="#add" data-toggle="modal" class="btn btn-primary btn-sm rounded-0 pull-right"><i class="fa fa-plus"></i> Add New Question</a>
			</div>
			<div class="card-body">
				<table class="table table-hover table-bordered" id="example" ui-options=ui-options="{
					&quot;paging&quot;: {
					&quot;enabled&quot;: true
					},
					&quot;filtering&quot;: {
					&quot;enabled&quot;: true
					},
					&quot;sorting&quot;: {
					&quot;enabled&quot;: true
					}}">
					<thead style="background-color: #464b58; color:white;">
						<tr>
							<td>#</td>
							<td>Question Title</td>
							<td class="text-center">Action</td>
						</tr></thead>
						<tbody style="background-color: white;">
						<?php $no=0; foreach ($get_question as $question) : $no++;?>

						<tr>
							<td><?=$no?></td>
							<td><?=$question->title?></td>
							
							<td class="text-center">
								<a href="#edit" onclick="edit('<?=$question->question_id?>')" class="btn btn-primary btn-sm rounded-0" data-toggle="modal"><i class="fa fa-pencil"></i>Edit</a>
								<a href="<?=base_url('index.php/question/hapus/'.$question->question_id)?>" onclick="return confirm('Are you sure to delete this book?')" class="btn btn-danger btn-sm rounded-0"><i class="fa fa-trash"></i>Delete</a>
							</td>
						</tr>
					<?php endforeach ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="modal" id="add">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header text-center" style=color:blue;>
					Add New Question
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
					</button>
				</div>
				<form action="<?=base_url('index.php/question/add')?>" method="post" enctype="multipart/form-data">
					<div class="modal-body">
					  <div class="form-group row">
						<div class="col-sm-2 "><label style=color:blue;>Title</label></div>
						<div class="col-sm-12">
						<input type="text" class="form-control" name="title">
						</div>
					   </div>
						 <div class="row">

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option1</label>
								<input type="text" class="form-control" name="option1">
							 </div>
							</div>

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option2</label>
								<input type="text" class="form-control" name="option2">
							 </div>
							</div>
							
						</div>

						<div class="row">

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option3</label>
								<input type="text" class="form-control" name="option3">
							 </div>
							</div>

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option4</label>
								<input type="text" class="form-control" name="option4">
							 </div>
							</div>
							
						</div>

						<div class="row">

							<div class="col md-6">
							  <div class="form-group">
								<label style=color:blue;> Select Correct Option</label>
								<select name="correct_option" class="form-control">
								<option vlaue="option1">Option No 1</option>
								<option vlaue="option2">Option No 2</option>
								<option vlaue="option3">Option No 3</option>
								<option vlaue="option4">Option No 4</option>
								</select>
							  </div>
							</div>
						
							<div class="col md-6">
							  <div class="form-group">
								<label style=color:blue;> Select Correct Option</label>
								<select name="category" required="form-control" id="category_id" class="form-control">
									<?php foreach ($category as $kat): ?>
										<option value="<?=$kat->category_id?>">
											<?=$kat->category_name ?>
										</option> 
									<?php endforeach ?>
								</select>
							</div>
						</div>
						</div>
						
						
						
					</div>
					<div class="modal-footer justify-content-end">
						<input type="submit" name="save" value="Save" class="btn btn-primary btn-sm rounded-0">
						<button type="button" class="btn btn-default btn-sm border rounded-0" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="modal fade" id="edit">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					Update Question
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span>
					<span class="sr-only">Close</span>
					</button>
				</div>
				<form action="<?=base_url('index.php/question/question_update')?>" method="post" enctype="multipart/form-data">
					<input type="hidden" name="question_id" id="question_id">
					<div class="modal-body">
					  <div class="form-group row">
						<div class="col-sm-2 "><label style=color:blue;>Title</label></div>
						<div class="col-sm-12">
						<input type="text" name="title" id="title" class="form-control">
						</div>
					   </div>
						 <div class="row">

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option1</label>
								<input type="text" name="option1" id="option1" class="form-control">
							 </div>
							</div>

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option2</label>
								<input type="text" name="option2" id="option2" class="form-control">
							 </div>
							</div>
							
						</div>

						<div class="row">

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option3</label>
								<input type="text" name="option3" id="option3" class="form-control">
							 </div>
							</div>

							<div class="col md-6">
							 <div class="form-group">
								<label style=color:blue;>Option4</label>
								<input type="text" name="option4" id="option4" class="form-control">
							 </div>
							</div>
							
						</div>

						<div class="row">

							<div class="col md-6">
							  <div class="form-group">
								<label style=color:blue;> Select Correct Option</label>
								<select name="correct_option" id="correct_option" class="form-control">
								<option vlaue="option1">Option No 1</option>
								<option vlaue="option2">Option No 2</option>
								<option vlaue="option3">Option No 3</option>
								<option vlaue="option4">Option No 4</option>
								</select>
							  </div>
							</div>
						
							<div class="col md-6">
							  <div class="form-group">
								<label style=color:blue;> Select Category</label>
								<select name="category" id="category" class="form-control">
									<?php foreach ($category as $kat): ?>
										<option value="<?=$kat->category_id?>">
											<?=$kat->category_name ?>
										</option> <?php endforeach ?>
								</select>
							</div>
						</div>
						
						
						
					</div>
					<div class="modal-footer justify-content-end">
						<input type="submit" name="save" value="Save" class="btn btn-primary btn-sm rounded-0">
						<button type="button" class="btn btn-default btn-sm border rounded-0" data-dismiss="modal">Close</button>
					</div>
				</form>
			</div>
			
		</div>
	</div>
</div>


<script type="text/javascript">
	$(document).ready(function()
	    {
			$('#example').DataTable();
		}
	);
	function edit(a) {
		$.ajax({
			type:"post",
			url:"<?=base_url()?>index.php/question/edit_question/"+a,
			dataType:"json",
			success:function(data){
				$("#question_id").val(data.question_id);
                $("#title").val(data.title);
				$("#option1").val(data.option1);
				$("#option2").val(data.option2);
				$("#option3").val(data.option3);
				$("#option4").val(data.option4);
				$("#correct_option").val(data.correct_option);
				$("#category").val(data.category_id);
				

			}
		});
	}
</script>
